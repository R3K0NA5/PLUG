<?php
// Uždrausti tiesioginę prieigą
if (!defined('ABSPATH')) exit;

// Administratoriaus skydelio peržiūros šablonas
?>
<div class="wrap">
    <h1>Nuolaidų Valdymas</h1>
    <p>Čia galite valdyti visas WooCommerce pažangias nuolaidas.</p>
</div>