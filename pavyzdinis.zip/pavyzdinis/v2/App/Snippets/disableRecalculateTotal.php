<?php
/**
 * @since 2.3.6
 */

add_filter('advanced_woo_discount_rules_do_recalculate_total', '__return_false');